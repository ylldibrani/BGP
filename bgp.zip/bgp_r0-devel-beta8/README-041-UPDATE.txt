===================================================================
			Bright Game Panel - PHP Game Control Panel
			  by warhawk3407 (warhawk3407@gmail.com)
===================================================================

http://www.bgpanel.net/
Version 0.4.5 (Release 0 DEVELOPER BETA 8)
November 23rd, 2013

===================================================================


WARNING:

Updating the panel from a previous release to this version (0.4.1)
will cause all your SERVERS to be SWITCHED OFF and the STATUS to be set as PENDING.

You will have to edit your servers and re-validate them (you have to update the "Path" field).

We updated what we previously called "Homedir Path" or "Home Directory".

Now, you have to specify the ABSOLUTE PATH of your game server executable (It has been renamed to "Path").
@see: http://www.computerhope.com/jargon/a/absopath.htm


EXAMPLE OF PATH:

/home/user/minecraft/server1/minecraft_server.jar
/home/user/csgo/server1/srcds_run
/home/user/mw3/server1/iw5mp_server.exe
