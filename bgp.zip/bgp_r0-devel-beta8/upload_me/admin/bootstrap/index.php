<?php
exit("<h1><b>403 Forbidden</b></h1>");
?>